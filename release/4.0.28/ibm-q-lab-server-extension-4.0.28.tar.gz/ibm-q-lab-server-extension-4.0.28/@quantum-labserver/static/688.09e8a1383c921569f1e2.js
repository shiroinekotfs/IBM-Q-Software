"use strict";
(self.webpackChunk_quantum_lab_server = self.webpackChunk_quantum_lab_server || []).push([
    [688], { 688: (e, a, t) => { t.r(a), t.d(a, { default: () => u }); const u = { id: "ibm-q-lab-server-extension:plugin", autoStart: !1, activate: () => {} } } }
]);